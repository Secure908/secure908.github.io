<?php

$recipient = "h1force@yandex.com, q2311@pharmacienast-chelles.com";

?>